import 'package:flutter/material.dart';
import '../models/pokemon_model.dart';
import '../services/services.dart';

class PokemonProvider extends ChangeNotifier {
  final PokemonApiService _apiService;
  final StorageService _storageService;
  final AuthService _authService;

  PokemonProvider({
    required PokemonApiService apiService,
    required StorageService storageService,
    required AuthService authService,
  })  : _apiService = apiService,
        _storageService = storageService,
        _authService = authService {
    _init();
  }

  final List<Pokemon> _pokemons = [];
  final List<Pokemon> _favorites = [];
  final List<Pokemon> _filteredPokemons = [];
  String _error = '';
  bool _isLoading = false;
  String? _currentUser;

  List<Pokemon> get pokemons => _pokemons;
  List<Pokemon> get favorites => _favorites;
  List<Pokemon> get filteredPokemons =>
      _filteredPokemons.isEmpty && _searchQuery.isEmpty
          ? _pokemons
          : _filteredPokemons;
  String get error => _error;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;

  String _searchQuery = '';

  Future<void> _init() async {
    _currentUser = await _authService.getCurrentUser();
    if (_currentUser != null) {
      await _loadFavorites();
    }
  }

  Future<void> loadPokemons() async {
    if (_isLoading) return;

    try {
      _isLoading = true;
      _error = '';
      notifyListeners();

      final pokemons = await _apiService.fetchPokemons();
      _pokemons.clear();
      _pokemons.addAll(pokemons);
      searchPokemon(_searchQuery);
    } catch (e) {
      _error = 'Erro ao carregar os Pokémon: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void searchPokemon(String query) {
    _searchQuery = query.toLowerCase();
    if (_searchQuery.isEmpty) {
      _filteredPokemons.clear();
    } else {
      _filteredPokemons.clear();
      _filteredPokemons.addAll(
        _pokemons.where((pokemon) =>
            pokemon.name.toLowerCase().contains(_searchQuery) ||
            pokemon.id.toString() == _searchQuery ||
            pokemon.types
                .any((type) => type.toLowerCase().contains(_searchQuery))),
      );
    }
    notifyListeners();
  }

  bool isFavorite(Pokemon pokemon) {
    return _favorites.any((p) => p.id == pokemon.id);
  }

  Future<void> toggleFavorite(Pokemon pokemon) async {
    if (!isAuthenticated) {
      _error = 'Você precisa estar logado para favoritar Pokémon';
      notifyListeners();
      return;
    }

    try {
      if (isFavorite(pokemon)) {
        _favorites.removeWhere((p) => p.id == pokemon.id);
      } else {
        _favorites.add(pokemon);
      }
      await _storageService.saveFavorites(_currentUser!, _favorites);
      notifyListeners();
    } catch (e) {
      _error = 'Erro ao atualizar favoritos: $e';
      notifyListeners();
    }
  }

  Future<void> _loadFavorites() async {
    try {
      if (_currentUser != null) {
        final favorites = await _storageService.getFavorites(_currentUser!);
        _favorites.clear();
        _favorites.addAll(favorites);
        notifyListeners();
      }
    } catch (e) {
      _error = 'Erro ao carregar favoritos: $e';
      notifyListeners();
    }
  }

  // Auth methods
  Future<bool> signIn(String email, String password) async {
    try {
      final success = await _authService.signIn(email, password);
      if (success) {
        _currentUser = email;
        await _loadFavorites();
        _error = '';
      } else {
        _error = 'Email ou senha inválidos';
      }
      notifyListeners();
      return success;
    } catch (e) {
      _error = 'Erro ao fazer login: $e';
      notifyListeners();
      return false;
    }
  }

  Future<bool> signUp(String email, String password) async {
    try {
      final success = await _authService.signUp(email, password);
      if (success) {
        _currentUser = email;
        _error = '';
      } else {
        _error = 'Erro ao criar conta';
      }
      notifyListeners();
      return success;
    } catch (e) {
      _error = 'Erro ao criar conta: $e';
      notifyListeners();
      return false;
    }
  }

  Future<void> signOut() async {
    try {
      await _authService.signOut();
      _currentUser = null;
      _favorites.clear();
      _pokemons.clear();
      _filteredPokemons.clear();
      _searchQuery = '';
      _error = '';
      notifyListeners();
    } catch (e) {
      _error = 'Erro ao fazer logout: $e';
      notifyListeners();
    }
  }
}
