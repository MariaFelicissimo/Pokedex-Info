class Pokemon {
  final int id;
  final String name;
  final String imageUrl;
  final List<String> types;
  final Map<String, int> stats;
  final double height;
  final double weight;
  final String description;

  Pokemon({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.types,
    required this.stats,
    required this.height,
    required this.weight,
    required this.description,
  });

  factory Pokemon.fromJson(Map<String, dynamic> json) {
    return Pokemon(
      id: json['id'] as int,
      name: (json['name'] as String).capitalize(),
      imageUrl: json['sprites']['other']['official-artwork']['front_default']
          as String,
      types: (json['types'] as List<dynamic>)
          .map((type) => (type['type']['name'] as String).capitalize())
          .toList(),
      stats: Map.fromEntries(
        (json['stats'] as List<dynamic>).map(
          (stat) => MapEntry(
            stat['stat']['name'] as String,
            stat['base_stat'] as int,
          ),
        ),
      ),
      height: (json['height'] as num) / 10, // Convert to meters
      weight: (json['weight'] as num) / 10, // Convert to kilograms
      description: json['description'] as String? ?? 'Descrição não disponível',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'imageUrl': imageUrl,
      'types': types,
      'stats': stats,
      'height': height,
      'weight': weight,
      'description': description,
    };
  }

  Pokemon copyWith({
    int? id,
    String? name,
    String? imageUrl,
    List<String>? types,
    Map<String, int>? stats,
    double? height,
    double? weight,
    String? description,
  }) {
    return Pokemon(
      id: id ?? this.id,
      name: name ?? this.name,
      imageUrl: imageUrl ?? this.imageUrl,
      types: types ?? this.types,
      stats: stats ?? this.stats,
      height: height ?? this.height,
      weight: weight ?? this.weight,
      description: description ?? this.description,
    );
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Pokemon && other.id == id;
  }

  @override
  int get hashCode => id.hashCode;
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
}
