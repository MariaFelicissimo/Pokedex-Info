import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/pokemon_model.dart';

class StorageService {
  static const String _userKey = 'current_user';
  static const String _favoritesPrefix = 'favorites_';

  // User methods
  Future<void> saveUser(String email) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_userKey, email);
    } catch (e) {
      print('Error saving user: $e');
      rethrow;
    }
  }

  Future<String?> getUser() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_userKey);
    } catch (e) {
      print('Error getting user: $e');
      return null;
    }
  }

  Future<void> removeUser() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_userKey);
    } catch (e) {
      print('Error removing user: $e');
      rethrow;
    }
  }

  // Favorites methods
  Future<void> saveFavorites(String userEmail, List<Pokemon> favorites) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favoritesJson = favorites.map((p) => p.toJson()).toList();
      await prefs.setString(
          '${_favoritesPrefix}$userEmail', json.encode(favoritesJson));
    } catch (e) {
      print('Error saving favorites: $e');
      rethrow;
    }
  }

  Future<List<Pokemon>> getFavorites(String userEmail) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final favoritesJson = prefs.getString('${_favoritesPrefix}$userEmail');

      if (favoritesJson != null) {
        final List<dynamic> decoded = json.decode(favoritesJson);
        return decoded.map((json) => Pokemon.fromJson(json)).toList();
      }
      return [];
    } catch (e) {
      print('Error getting favorites: $e');
      return [];
    }
  }

  Future<void> removeFavorites(String userEmail) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove('${_favoritesPrefix}$userEmail');
    } catch (e) {
      print('Error removing favorites: $e');
      rethrow;
    }
  }

  // Clear all data
  Future<void> clearAll() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
    } catch (e) {
      print('Error clearing storage: $e');
      rethrow;
    }
  }
}
