import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/pokemon_model.dart';

class FirebaseService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Auth methods
  Future<UserCredential?> signUp(String email, String password) async {
    try {
      final userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Create user document in Firestore
      if (userCredential.user != null) {
        await _firestore.collection('users').doc(userCredential.user!.uid).set({
          'email': email,
          'createdAt': FieldValue.serverTimestamp(),
        });
      }

      return userCredential;
    } catch (e) {
      print('Error in signUp: $e');
      rethrow;
    }
  }

  Future<UserCredential?> signIn(String email, String password) async {
    try {
      return await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
    } catch (e) {
      print('Error in signIn: $e');
      rethrow;
    }
  }

  Future<void> signOut() async {
    try {
      await _auth.signOut();
    } catch (e) {
      print('Error in signOut: $e');
      rethrow;
    }
  }

  User? getCurrentUser() {
    return _auth.currentUser;
  }

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Firestore methods
  Future<void> saveFavorites(String userId, List<Pokemon> favorites) async {
    try {
      final userDoc = _firestore.collection('users').doc(userId);
      final batch = _firestore.batch();

      // Delete existing favorites
      final existingFavorites = await userDoc.collection('favorites').get();
      for (var doc in existingFavorites.docs) {
        batch.delete(doc.reference);
      }

      // Add new favorites
      for (var pokemon in favorites) {
        final docRef =
            userDoc.collection('favorites').doc(pokemon.id.toString());
        batch.set(docRef, pokemon.toJson());
      }

      await batch.commit();
    } catch (e) {
      print('Error in saveFavorites: $e');
      rethrow;
    }
  }

  Future<List<Pokemon>> getFavorites(String userId) async {
    try {
      final snapshot = await _firestore
          .collection('users')
          .doc(userId)
          .collection('favorites')
          .get();

      return snapshot.docs.map((doc) => Pokemon.fromJson(doc.data())).toList();
    } catch (e) {
      print('Error in getFavorites: $e');
      return [];
    }
  }

  // User data methods
  Future<void> updateUserProfile(
      String userId, Map<String, dynamic> data) async {
    try {
      await _firestore.collection('users').doc(userId).update(data);
    } catch (e) {
      print('Error in updateUserProfile: $e');
      rethrow;
    }
  }

  Future<Map<String, dynamic>?> getUserProfile(String userId) async {
    try {
      final doc = await _firestore.collection('users').doc(userId).get();
      return doc.data();
    } catch (e) {
      print('Error in getUserProfile: $e');
      return null;
    }
  }

  // Pokemon data methods
  Future<void> savePokemonData(Pokemon pokemon) async {
    try {
      await _firestore
          .collection('pokemons')
          .doc(pokemon.id.toString())
          .set(pokemon.toJson());
    } catch (e) {
      print('Error in savePokemonData: $e');
      rethrow;
    }
  }

  Future<Pokemon?> getPokemonData(String pokemonId) async {
    try {
      final doc = await _firestore.collection('pokemons').doc(pokemonId).get();
      if (doc.exists) {
        return Pokemon.fromJson(doc.data()!);
      }
      return null;
    } catch (e) {
      print('Error in getPokemonData: $e');
      return null;
    }
  }

  Stream<List<Pokemon>> getFavoritesStream(String userId) {
    return _firestore
        .collection('users')
        .doc(userId)
        .collection('favorites')
        .snapshots()
        .map((snapshot) =>
            snapshot.docs.map((doc) => Pokemon.fromJson(doc.data())).toList());
  }
}
