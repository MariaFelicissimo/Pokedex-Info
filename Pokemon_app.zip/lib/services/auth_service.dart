import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase_service.dart';
import 'storage_service.dart';

class AuthService {
  final FirebaseService _firebase;
  final StorageService _storage;

  AuthService({
    required FirebaseService firebase,
    required StorageService storage,
  })  : _firebase = firebase,
        _storage = storage;

  Future<bool> signIn(String email, String password) async {
    try {
      final userCredential = await _firebase.signIn(email, password);
      if (userCredential?.user != null) {
        await _storage.saveUser(email);
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error in signIn: $e');
      return false;
    }
  }

  Future<bool> signUp(String email, String password) async {
    try {
      final userCredential = await _firebase.signUp(email, password);
      if (userCredential?.user != null) {
        await _storage.saveUser(email);
        return true;
      }
      return false;
    } catch (e) {
      debugPrint('Error in signUp: $e');
      return false;
    }
  }

  Future<void> signOut() async {
    try {
      await Future.wait([
        _firebase.signOut(),
        _storage.removeUser(),
      ]);
    } catch (e) {
      debugPrint('Error in signOut: $e');
      rethrow;
    }
  }

  Future<String?> getCurrentUser() async {
    try {
      final firebaseUser = _firebase.getCurrentUser();
      if (firebaseUser != null) {
        return firebaseUser.email;
      }
      return await _storage.getUser();
    } catch (e) {
      debugPrint('Error in getCurrentUser: $e');
      return null;
    }
  }

  Stream<User?> get authStateChanges => _firebase.authStateChanges;

  bool _isValidEmail(String email) {
    if (email.isEmpty) return false;

    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    return emailRegex.hasMatch(email);
  }

  bool _isValidPassword(String password) {
    return password.length >= 6;
  }
}
