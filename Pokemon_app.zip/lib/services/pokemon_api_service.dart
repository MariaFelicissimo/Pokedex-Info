import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/pokemon_model.dart';

class PokemonApiService {
  static const String _baseUrl = 'https://pokeapi.co/api/v2';

  Future<List<Pokemon>> fetchPokemons({int limit = 151}) async {
    final List<Pokemon> pokemons = [];

    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/pokemon?limit=$limit'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final results = data['results'] as List;

        for (var pokemon in results) {
          try {
            final pokemonData = await _fetchPokemonDetails(pokemon['url']);
            if (pokemonData != null) {
              pokemons.add(pokemonData);
            }
          } catch (e) {
            print('Error fetching pokemon details: $e');
            continue;
          }
        }
      }
    } catch (e) {
      throw Exception('Failed to load pokemons: $e');
    }

    return pokemons;
  }

  Future<Pokemon?> _fetchPokemonDetails(String url) async {
    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final pokemonData = json.decode(response.body);

        // Fetch species data for description
        final speciesUrl = pokemonData['species']['url'];
        final description = await _fetchPokemonDescription(speciesUrl);

        // Add description to pokemon data
        pokemonData['description'] = description;

        return Pokemon.fromJson(pokemonData);
      }
      return null;
    } catch (e) {
      print('Error in _fetchPokemonDetails: $e');
      return null;
    }
  }

  Future<String> _fetchPokemonDescription(String speciesUrl) async {
    try {
      final response = await http.get(Uri.parse(speciesUrl));

      if (response.statusCode == 200) {
        final speciesData = json.decode(response.body);
        final descriptions = speciesData['flavor_text_entries'] as List;

        // Find Portuguese description if available, otherwise use English
        final description = descriptions.firstWhere(
          (entry) => entry['language']['name'] == 'pt-br',
          orElse: () => descriptions.firstWhere(
            (entry) => entry['language']['name'] == 'en',
            orElse: () => {'flavor_text': 'Descrição não disponível'},
          ),
        )['flavor_text'] as String;

        return description.replaceAll('\n', ' ');
      }
      return 'Descrição não disponível';
    } catch (e) {
      print('Error in _fetchPokemonDescription: $e');
      return 'Descrição não disponível';
    }
  }

  Future<Pokemon?> fetchPokemonById(int id) async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/pokemon/$id'),
      );

      if (response.statusCode == 200) {
        final pokemonData = json.decode(response.body);
        final speciesUrl = pokemonData['species']['url'];
        final description = await _fetchPokemonDescription(speciesUrl);
        pokemonData['description'] = description;
        return Pokemon.fromJson(pokemonData);
      }
      return null;
    } catch (e) {
      print('Error in fetchPokemonById: $e');
      return null;
    }
  }

  Future<Pokemon?> fetchPokemonByName(String name) async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/pokemon/${name.toLowerCase()}'),
      );

      if (response.statusCode == 200) {
        final pokemonData = json.decode(response.body);
        final speciesUrl = pokemonData['species']['url'];
        final description = await _fetchPokemonDescription(speciesUrl);
        pokemonData['description'] = description;
        return Pokemon.fromJson(pokemonData);
      }
      return null;
    } catch (e) {
      print('Error in fetchPokemonByName: $e');
      return null;
    }
  }
}
